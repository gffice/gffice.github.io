rm ./s.sh >/dev/null
rm ./php/php >/dev/null
rm ./php/config.json >/dev/null